<?php
$servidor = "db";
$usuario = "root";
$senha = "123";
$banco = "hospital2b";

$conexao = mysqli_connect($servidor, $usuario, $senha, $banco);
?>