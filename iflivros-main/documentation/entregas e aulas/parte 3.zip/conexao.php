<?php
    $servidor = "db";
    $usuario = "root";
    $senha = "123";
    $banco = "IF_livros";

    $conexao = mysqli_connect($servidor, $usuario, $senha, $banco);

?>